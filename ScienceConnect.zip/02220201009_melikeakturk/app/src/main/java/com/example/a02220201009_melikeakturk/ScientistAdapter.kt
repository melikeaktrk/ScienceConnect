package com.example.a02220201009_melikeakturk

import Scientist
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.a02220201009_melikeakturk.R
import com.squareup.picasso.Picasso

class ScientistAdapter(
    context: Context,
    private val scientistList: List<Scientist>
) : ArrayAdapter<Scientist>(context, 0, scientistList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val scientist = getItem(position)
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.scientist_item, parent, false)

        val nameTextView: TextView = view.findViewById(R.id.scientistName)
        val surnameTextView: TextView = view.findViewById(R.id.scientistSurname)
        val birthPlaceTextView: TextView = view.findViewById(R.id.scientistBirthPlace)
        val birthDateTextView: TextView = view.findViewById(R.id.scientistBirthDate)
        val deathDateTextView: TextView = view.findViewById(R.id.scientistDeathDate)
        val contributionsTextView: TextView = view.findViewById(R.id.scientistContributions)
        val uploaderEmailTextView: TextView = view.findViewById(R.id.scientistUploaderEmail)
        val imageView: ImageView = view.findViewById(R.id.scientistImageView)

        nameTextView.text = scientist?.name
        surnameTextView.text = scientist?.surname
        birthPlaceTextView.text = scientist?.birthPlace
        birthDateTextView.text = scientist?.birthDate
        deathDateTextView.text = scientist?.deathDate
        contributionsTextView.text = scientist?.contributions
        uploaderEmailTextView.text = "Yükleyen: ${scientist?.uploaderEmail}"

        // Resim URL'sini kontrol et
        if (scientist?.imageUrl?.isNotEmpty() == true) {
            imageView.visibility = View.VISIBLE // Resim alanını görünür yap
            Picasso.get().load(scientist.imageUrl).into(imageView) // Resmi yükle
        } else {
            imageView.visibility = View.GONE // Resim URL yoksa alanı gizle
        }

        return view
    }
}