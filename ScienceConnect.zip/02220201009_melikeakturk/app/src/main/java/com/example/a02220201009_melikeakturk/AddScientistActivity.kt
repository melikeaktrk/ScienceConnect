package com.example.a02220201009_melikeakturk

import Scientist
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class AddScientistActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var scientistName: EditText
    private lateinit var scientistSurname: EditText
    private lateinit var scientistBirthPlace: EditText
    private lateinit var scientistBirthDate: EditText
    private lateinit var scientistDeathDate: EditText
    private lateinit var scientistContributions: EditText
    private lateinit var uploadButton: Button

    private var imageUri: Uri? = null
    private lateinit var storageReference: StorageReference
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_scientist)

        // Firebase Başlat
        storageReference = FirebaseStorage.getInstance().reference
        firestore = FirebaseFirestore.getInstance()

        // Görünümleri Tanımla
        imageView = findViewById(R.id.imageView)
        scientistName = findViewById(R.id.scientistName)
        scientistSurname = findViewById(R.id.scientistSurname)
        scientistBirthPlace = findViewById(R.id.scientistBirthPlace)
        scientistBirthDate = findViewById(R.id.scientistBirthDate)
        scientistDeathDate = findViewById(R.id.scientistDeathDate)
        scientistContributions = findViewById(R.id.scientistContributions)
        uploadButton = findViewById(R.id.uploadScientistButton)

        // Resim Seçme
        imageView.setOnClickListener {
            openGallery()
        }

        // Gönderi Yükleme
        uploadButton.setOnClickListener {
            val name = scientistName.text.toString()
            val surname = scientistSurname.text.toString()
            val birthPlace = scientistBirthPlace.text.toString()
            val birthDate = scientistBirthDate.text.toString()
            val deathDate = scientistDeathDate.text.toString()
            val contributions = scientistContributions.text.toString()

            if (name.isNotEmpty() && surname.isNotEmpty() && birthPlace.isNotEmpty()) {
                uploadScientistData(name, surname, birthPlace, birthDate, deathDate, contributions)
            } else {
                Toast.makeText(this, "Lütfen tüm alanları doldurun.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { result: Uri? ->
            result?.let {
                imageView.setImageURI(it)
                imageUri = it
            }
        }

    private fun openGallery() {
        galleryLauncher.launch("image/*")
    }

    private fun uploadScientistData(
        name: String,
        surname: String,
        birthPlace: String,
        birthDate: String,
        deathDate: String,
        contributions: String
    ) {
        val currentUserEmail = FirebaseAuth.getInstance().currentUser?.email ?: "Bilinmeyen Kullanıcı"

        if (imageUri != null) {
            val fileReference = storageReference.child("scientists/${System.currentTimeMillis()}.jpg")
            fileReference.putFile(imageUri!!).addOnSuccessListener {
                fileReference.downloadUrl.addOnSuccessListener { uri ->
                    saveScientistToFirestore(
                        name,
                        surname,
                        birthPlace,
                        birthDate,
                        deathDate,
                        contributions,
                        uri.toString(), // Resim URL'si
                        currentUserEmail
                    )
                }
            }.addOnFailureListener { exception ->
                Log.e("AddScientistActivity", "uploadScientistData: Resim yükleme hatası: ${exception.message}")
                Toast.makeText(this, "Resim yüklenirken hata oluştu.", Toast.LENGTH_SHORT).show()
            }
        } else {
            // Resim yoksa boş bir string gönder
            saveScientistToFirestore(
                name,
                surname,
                birthPlace,
                birthDate,
                deathDate,
                contributions,
                "",
                currentUserEmail
            )
        }
    }

    private fun saveScientistToFirestore(
        name: String,
        surname: String,
        birthPlace: String,
        birthDate: String,
        deathDate: String,
        contributions: String,
        imageUrl: String,
        uploaderEmail: String
    ) {
        val scientist = Scientist(
            name = name,
            surname = surname,
            birthPlace = birthPlace,
            birthDate = birthDate,
            deathDate = deathDate,
            contributions = contributions,
            imageUrl = imageUrl,
            uploaderEmail = uploaderEmail
        )

        // Firestore'a kaydet
        firestore.collection("scientists")
            .add(scientist) // Firestore'a ekle
            .addOnSuccessListener {
                Toast.makeText(this, "Bilim insanı başarıyla yüklendi.", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
                finish()  // Mevcut aktiviteyi sonlandır
            }
            .addOnFailureListener { exception ->
                Toast.makeText(this, "Veri kaydedilirken hata oluştu: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}