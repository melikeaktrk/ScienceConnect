data class Scientist(
    val name: String = "",
    val surname: String = "",
    val birthPlace: String = "",
    val birthDate: String = "",
    val deathDate: String = "",
    val contributions: String = "",
    val imageUrl: String = "",
    val uploaderEmail: String = "" // Gönderiyi kimin yüklediği
)