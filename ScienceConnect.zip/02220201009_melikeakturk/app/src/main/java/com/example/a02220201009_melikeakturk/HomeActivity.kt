package com.example.a02220201009_melikeakturk

import Scientist
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot

class HomeActivity : AppCompatActivity() {

    private lateinit var userNameTextView: TextView
    private lateinit var scientistListView: ListView
    private lateinit var firestore: FirebaseFirestore
    private lateinit var scientistAdapter: ScientistAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Toolbar'ı tanımla ve ActionBar olarak ayarla
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // TextView ve ListView referanslarını al
        userNameTextView = findViewById(R.id.userNameTextView)
        scientistListView = findViewById(R.id.scientistListView)

        // Firebase Firestore referansını al
        firestore = FirebaseFirestore.getInstance()

        // Kullanıcı adını Firebase Authentication'dan al ve TextView'e yazdır
        val userName = FirebaseAuth.getInstance().currentUser?.email ?: "Kullanıcı"
        userNameTextView.text = "Hoş Geldiniz: $userName"

        // Bilim insanlarını listeye çek
        fetchScientists()
    }

    // Menü oluşturma işlemi
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_home, menu) // Menü dosyasını bağlama
        return true
    }

    // Menü öğelerine tıklama işlemleri
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_add_post -> {
                // Gönderi ekleme sayfasına git
                val intent = Intent(this, AddScientistActivity::class.java)
                startActivity(intent)
                return true
            }

            R.id.menu_logout -> {
                // Çıkış yap
                FirebaseAuth.getInstance().signOut()
                Toast.makeText(this, "Çıkış yapıldı.", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun fetchScientists() {
        val scientistList = mutableListOf<Scientist>() // Bilim insanlarını tutacak liste

        // Firebase Firestore'dan "scientists" koleksiyonunu alıyoruz
        firestore.collection("scientists")
            .get()
            .addOnSuccessListener { snapshot: QuerySnapshot ->
                scientistList.clear() // Eski listeyi temizle
                for (dataSnapshot in snapshot.documents) {
                    val scientist = dataSnapshot.toObject(Scientist::class.java)
                    if (scientist != null) {
                        scientistList.add(scientist) // Yeni bilim insanını listeye ekle
                    }
                }

                // ListView'i adapte et ve verileri yükle
                scientistAdapter = ScientistAdapter(this@HomeActivity, scientistList)
                scientistListView.adapter = scientistAdapter
            }
            .addOnFailureListener { error ->
                // Hata durumunda kullanıcıya bildirim yap
                Toast.makeText(this@HomeActivity, "Veri alınamadı: ${error.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
